/*
 * File:   clocks.h
 * Author: Sarim
 *
 * Created on October 12, 2021, 1:09 AM
 */


#include "xc.h"

//Configuration of the clock
void clkConfig(void);
