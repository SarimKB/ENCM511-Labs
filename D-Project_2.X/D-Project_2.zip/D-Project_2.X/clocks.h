/*
 * File:   clocks.h
 * Author: Sarim
 *
 * Created on October 12, 2021, 1:09 AM
 */

//This code is given from d2L under "Driver Topic 2 : HW IO Control and Timers"
#include "xc.h"

//Configuration of the clock
void NewClk(unsigned int);
